/* 
 * File:   Link.h
 * Author: Dr. Mark E. Lehr
 * Created on September 19, 2018, 9:08 PM
 */

#ifndef LINK_H
#define LINK_H

struct Link{
    int data;
    Link *next;
    Link *prev;
};

#endif /* LINK_H */

