#include "Triangle.h"

Triangle::Triangle(int szRow) {
    this->szRow = szRow;
    this->records = new RowAray*[szRow];
    for (short i = 0; i < szRow; i++) {
        records[i] = new RowAray(szRow);
    }
}

Triangle::~Triangle() {
    for (short i = 0; i < szRow; i++) {
        delete records[i];
    }
    delete[] records;
}

int Triangle::getData(int x, int y) {
    return this->records[y]->getData(x);
}