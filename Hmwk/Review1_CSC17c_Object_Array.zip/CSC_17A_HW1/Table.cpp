#include "Table.h"

Table::Table(int szRow, int szCol) {
    this->szRow = szRow;
    this->szCol = szCol;
    this->records = new RowAray*[szRow*szCol];
    for (short i = 0; i < szCol; i++) {
        records[i] = new RowAray(szRow);
    }
}

Table::~Table() {
    for (short i = 0; i < szRow * szCol; i++) {
        delete records[i];
    }
    delete[] records;
}

int Table::getData(int x, int y) {
    return this->records[y]->getData(x);
}