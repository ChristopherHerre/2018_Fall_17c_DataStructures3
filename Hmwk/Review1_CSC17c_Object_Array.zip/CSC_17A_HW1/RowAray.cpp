#include <cstdlib>
using namespace std;

#include "RowAray.h"

RowAray::RowAray(int size) {
    this->size = size;
    this->rowData = new int[size];
    for (short i = 0; i < size; i++) {
        rowData[i] = (rand() % 89) + 10;// always at least 2 digits
    }
}

RowAray::~RowAray() {
    delete[] rowData;
}