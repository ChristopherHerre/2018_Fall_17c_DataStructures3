#include "PlusTab.h"

PlusTab PlusTab::operator +(const PlusTab& tab) {
    PlusTab result(tab.szRow, tab.szCol);
    for (short x = 0; x < tab.szRow; x++) {
        for (short y = 0; y < tab.szCol; y++) {
            short sum = this->getData(x, y) + tab.getData(x, y);
            result.columns[y]->setData(x, sum);
        }
    }
    return result;
}