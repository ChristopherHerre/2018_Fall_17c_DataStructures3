#include <cstdlib>

using namespace std;

#include "RowAray.h"

RowAray::RowAray(unsigned int size) {
    this->size = size;
    this->rowData = new int[size];
    for (short i = 0; i < size; i++) {
        this->setData(i, (rand() % 89) + 10);
    }
}

RowAray::~RowAray() {
    delete[] rowData;
}

void RowAray::setData(int index, int val) {
    this->rowData[index] = val;
}