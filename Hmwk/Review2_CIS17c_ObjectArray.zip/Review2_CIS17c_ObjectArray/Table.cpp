#include "Table.h"

Table::Table(unsigned int szRow, unsigned int szCol) {
    this->szRow = szRow;
    this->szCol = szCol;
    columns = new RowAray*[szCol];
    for (short i = 0; i < szCol; i++) {
        columns[i] = new RowAray(szRow);
    }
}

Table::Table(const Table& tab) {
    this->szRow = tab.szRow;
    this->szCol = tab.szCol;
    this->columns = tab.columns;
}

Table::~Table() {
    // segmentation fault??
    /*for (short i = 0; i < szCol; i++) {
        delete[] columns[i];
    }
    delete[] columns;*/
}

int Table::getData(int x, int y) const {
    return this->columns[y]->getData(x);
}

void Table::setData(int x, int y, int val) {
    this->columns[y]->setData(x, val);
}