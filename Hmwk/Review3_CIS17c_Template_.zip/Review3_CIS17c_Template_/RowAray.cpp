#include "RowAray.h"

template <class T>
RowAray<T>::RowAray(int size)
{
    this->size = size;
    this->rowData = new T[size];
    for (short i = 0; i < size; i++)
    {
        setData(i, (rand() % 89) + 10);
    }
}

template <class T>
RowAray<T>::~RowAray()
{
    delete[] rowData;
}

template <class T>
void RowAray<T>::setData(int i, T t)
{
    this->rowData[i] = t;
}

template class RowAray<int>;
template class RowAray<float>;