#include <cstdlib>

#include "Table.h"

template <class T>
Table<T>::Table(unsigned int szRow, unsigned int szCol)
{
    this->szRow = szRow;
    this->szCol = szCol;
    this->columns = new RowAray<T>*[szCol];
    for (short i = 0; i < szCol; i++)
    {
        this->columns[i] = new RowAray<T>(szRow);
    }
}

template <class T>
Table<T>::Table(const Table<T>& tab)
{
    this->szRow = tab.getSzRow();
    this->szCol = tab.getSzCol();
    this->columns = tab.columns;
    
}

template <class T>
Table<T>::~Table()
{
    //delete columns;
}

template <class T>
Table<T> Table<T>::operator +(const Table<T>& tab)
{
    Table result(tab.szRow, tab.szCol);
    for (short x = 0; x < tab.szRow; x++)
    {
        for (short y = 0; y < tab.szCol; y++)
        {
            short sum = this->getData(x, y) + tab.getData(x, y);
            result.columns[y]->setData(x, sum);
        }
    }
    return result;
}

template <class T>
T Table<T>::getData(int x, int y) const
{
    return this->columns[y]->getData(x);
}

template class Table<int>;
template class Table<float>;