
/* 
 * File:   main.cpp
 * Author: Christopher Herre
 *
 * Created on September 3, 2018, 11:28 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

float* readData(string, float&);
void printSums(float, float, float, float);

const short NUM_DATA = 37;
const short SCALED_ERR = 10;
const short WIDTH = 10;
const short WIDTH2 = 15;

int main(int argc, char** argv) {
    float sumx = 0;
    float sumy = 0;
    float summcs = 0;
    cout << fixed << setprecision(2) << endl;
    cout << right << setw(WIDTH) << "F (X)" << setw(WIDTH) << "C (Y)"
            << setw(WIDTH) << "Y'" << setw(WIDTH) << "X*Y'"
            << setw(WIDTH) << "X*X" << endl;
    cout << endl;
    float* fs = readData("DegreeF_X.txt", sumx); // fahrenheit data
    float* cs = readData("DegreeC_Y.txt", sumy); // celsius data
    float* mcs = readData("Measured_C.txt", summcs); // celsius plus 
    // AKA x * Y'
    float* xTimesMCs = new float[NUM_DATA];
    float sumxy = 0;
    for (short i = 0; i < NUM_DATA; i++) {
        xTimesMCs[i] = fs[i] * mcs[i];
        sumxy += xTimesMCs[i];
    }
    float* xx = new float[NUM_DATA];
    float sumxx = 0;
    for (short i = 0; i < NUM_DATA; i++) {
        xx[i] = fs[i] * fs[i];
        sumxx += xx[i];
    }
    for (short i = 0; i < NUM_DATA; i++) {
        cout << right << setw(WIDTH) << fs[i] << setw(WIDTH) << cs[i]
                << setw(WIDTH) << mcs[i] << setw(WIDTH) << xTimesMCs[i]
                << setw(WIDTH) << xx[i] << endl;
    }
    printSums(sumx, sumy, sumxy, sumxx);
    // clean up uses of new
    delete[] fs;
    delete[] cs;
    delete[] mcs;
    delete[] xTimesMCs;
    delete[] xx;
    return 0;
}

float* readData(string file, float& sum) {
    float item;
    float* a = new float[NUM_DATA];
    fstream input;
    input.open(file.c_str());
    short index = 0;
    while (input >> item) {
        a[index] = item;
        // sum the values read
        sum += item;
        index++;
    }
    input.close();
    return a;
}

void printSums(float sumx, float sumy, float sumxy, float sumxx) {   
    float sumx2 = sumx * sumx; // sumx^2
    float slope = (sumx * sumy / NUM_DATA - sumxy) / (sumx2 / NUM_DATA - sumxx);
    float b = (sumy - slope * sumx) / NUM_DATA;
    cout << endl;
    cout << setw(WIDTH) << right << "sumx= " << setw(WIDTH2)
            << right << sumx << endl;
    cout << setw(WIDTH) << right << "sumy= " << setw(WIDTH2)
            << right << sumy << endl;
    cout << setw(WIDTH) << right << "sumxy= " << setw(WIDTH2)
            << right << sumxy << endl;
    cout << setw(WIDTH) << right << "sumxx= " << setw(WIDTH2)
            << right << sumxx << endl;
    cout << setw(WIDTH) << right << "sumx^2= " << setw(WIDTH2)
            << right << sumx2 << endl;
    cout << setprecision(9) << endl;
    cout << setw(WIDTH) << right << "m= " << setw(WIDTH2)
            << right << slope << endl;
    cout << setw(WIDTH) << right << "b= " << setw(WIDTH2)
            << right << b << endl;
}